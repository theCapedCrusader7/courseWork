.mode csv
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/teams.csv --skip 1 teams
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/players.csv --skip 1 players
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/coaches_career.csv --skip 1 coaches_career
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/coaches_season.csv --skip 1 coaches_season
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/player_playoffs.csv --skip 1 player_playoffs
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/player_playoffs_career.csv --skip 1 player_playoffs_career
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/player_regular_season.csv --skip 1 player_regular_season
.import /home/saqib/iith/courseWork/sem5/CS3550/assignment1/player_regular_season_career.csv --skip 1 player_regular_season_career

