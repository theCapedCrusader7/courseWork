DROP TABLE players;
DROP TABLE teams;
DROP TABLE coaches_season;
DROP TABLE coaches_career
DROP TABLE player_playoffs
DROP TABLE player_playoffs_career
DROP TABLE player_regular_season
DROP TABLE player_regular_season_career

